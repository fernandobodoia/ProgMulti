import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { GerenciarPage} from "../gerenciar/gerenciar";


@IonicPage()
@Component({
  selector: 'page-pesquisar',
  templateUrl: 'pesquisar.html',
})
export class PesquisarPage {

  searchQuery: string = '';
  items: string[];
  
 
  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.initializeItems();
  }

  openSobre(){
    this.navCtrl.push(GerenciarPage, {}, {animate: true} );    
  }

  initializeItems() {
    this.items = [
      'Dom Quixote, Miguel de Cervantes, 1605',
      'Guerra e Paz, Liev Tolstói, 1869',
      'A Montanha Mágica, Thomas Mann, 1924',
      'Cem Anos de Solidão, Gabriel García Márquez, 1967',
      'Ulisses, James Joyce, 1922',
      'Em Busca do Tempo Perdido, Marcel Proust, 1913',
      'A Divina Comédia, Dante Alighieri, 1321',
      'O Homem sem Qualidades, Robert Musil, 1930-1943',
      'O Processo, Franz Kafka, 1925',
      'O Som e a Fúria, William Faulkner, 1929',
    ];
  }

  getItems(ev: any) {
    // Reset items back to all of the items
    this.initializeItems();

    // set val to the value of the searchbar
    const val = ev.target.value;

    // if the value is an empty string don't filter the items
    if (val && val.trim() != '') {
      this.items = this.items.filter((item) => {
        return (item.toLowerCase().indexOf(val.toLowerCase()) > -1);
      })
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PesquisarPage');
  }

}
