package br.usjt.previsaodotempospringboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import br.usjt.previsaodotempospringboot.model.DiaSemana;

@Service
public interface DiaSemanaRepository extends JpaRepository<DiaSemana, Long>{

}