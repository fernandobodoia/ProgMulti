package br.usjt.previsaodotempospringboot.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import br.usjt.previsaodotempospringboot.model.Previsao;

public interface PrevisaoRepository extends JpaRepository<Previsao, Long>{
}


