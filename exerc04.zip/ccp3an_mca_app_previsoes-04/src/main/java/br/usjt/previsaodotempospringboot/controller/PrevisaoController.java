package br.usjt.previsaodotempospringboot.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import br.usjt.previsaodotempospringboot.model.Previsao;

import br.usjt.previsaodotempospringboot.service.PrevisaoService;

@Controller
public class PrevisaoController {
	
	@Autowired
	private PrevisaoService PrevisaoService;
	
	@GetMapping("/previsao")
	public ModelAndView listarTodos() {
		// passe o nome da página ao construtor
		ModelAndView mv = new ModelAndView("lista_tempo");
		// para modelar o formulário
		mv.addObject(new Previsao());
		// Busque a coleção com o service
		List<Previsao> previsoes = PrevisaoService.listarTodos();
		// adicione a coleção ao objeto ModelAndView
		mv.addObject("previsoes", previsoes);
		// devolva o ModelAndView
		return mv;
	}
	
	@PostMapping("/previsao")
	public String adicionarPrevisao(Previsao previsao) {
		//salvando com o service
		PrevisaoService.salvar(previsao);
		return "redirect:/previsao";
	}
}