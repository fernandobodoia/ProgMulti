package br.usjt.previsaodotempospringboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.usjt.previsaodotempospringboot.model.Cidade;

public interface CidadeRepository extends JpaRepository<Cidade, Long> {

}