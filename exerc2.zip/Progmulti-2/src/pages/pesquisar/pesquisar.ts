import { Component } from '@angular/core';
import { IonicPage, NavController} from 'ionic-angular';
import { Livro } from '../../model/livro';
import {DestinoPage} from '../destino/destino';


@IonicPage()
@Component({
  selector: 'page-pesquisar',
  templateUrl: 'pesquisar.html',
})
export class PesquisarPage {
  public items: Livro[];
  
  constructor(public navCtrl: NavController) {

      var l1 = {nome:'Dom Quixote', autor: 'Miguel de Cervantes, 1605',editora:''};
      var l2 = {nome:'Guerra e Paz', autor: 'Liev Tolstói, 1869',editora:''};
      var l3 = {nome:'A Montanha Mágica', autor: 'Thomas Mann, 1924',editora:''}
      var l4 = {nome:'Cem Anos de Solidão', autor: 'Gabriel García Márquez, 1967',editora:''};
      var l5 = {nome:'Ulisses', autor: 'James Joyce',editora:''};
      var l6 = {nome:'Em Busca do Tempo Perdido', autor: 'Marcel Proust - 1913', editora:''};
      var l7 = {nome:'A Divina Comédia', autor: 'Dante Alighieri, 1321',editora:''};
      var l8 = {nome:'O Homem sem Qualidades', autor: 'Robert Musil, 1930-1943', editora:''};
      var l9 = {nome:'O Processo', autor: 'Franz Kafka',editora:''};
      var l10 = {nome:'O Som e a Fúria', autor: 'William Faulkner, 1929',editora:''};

    this.items = [l1, l2, l3, l4, l5, l6, l7, l8, l9, l10];

  }
  irParaDestino(item:Livro):void{
    this.navCtrl.push(DestinoPage, {livroSelecionado: item});
  }
  
}
